/*
  Simple DirectMedia Layer
  Copyright (C) 1997-2014 Sam Lantinga <slouken@libsdl.org>

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.
*/

/*
  Contributed by Brandon Schaefer, <brandon.schaefer@canonical.com>
*/

#ifndef _SDL_mirframebuffer_h
#define _SDL_mirframebuffer_h

#include "../SDL_sysvideo.h"

#include "SDL_mirvideo.h"

extern int
MIR_CreateWindowFramebuffer(_THIS, SDL_Window* sdl_window, Uint32* format,
                            void** pixels, int* pitch);

extern int
MIR_UpdateWindowFramebuffer(_THIS, SDL_Window* sdl_window,
                            const SDL_Rect* rects, int numrects);

extern void
MIR_DestroyWindowFramebuffer(_THIS, SDL_Window* sdl_window);

#endif /* _SDL_mirframebuffer_h */

/* vi: set ts=4 sw=4 expandtab: */

